package com.cddb.demo.book.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cddb.demo.model.book.Book;

public interface BookRepo extends JpaRepository<Book, Integer> {

}
