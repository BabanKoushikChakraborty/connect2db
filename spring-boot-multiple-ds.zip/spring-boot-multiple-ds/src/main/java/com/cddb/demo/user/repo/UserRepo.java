package com.cddb.demo.user.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cddb.demo.model.user.User;

public interface UserRepo extends JpaRepository<User, Integer>
{

}
