package com.cddb.demo;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cddb.demo.book.repo.BookRepo;
import com.cddb.demo.model.book.Book;
import com.cddb.demo.model.user.User;
import com.cddb.demo.user.repo.UserRepo;

import jakarta.annotation.PostConstruct;

@RestController
@ComponentScan(basePackages = {"com.cddb.demo"})
@SpringBootApplication
public class SpringBootMultipleDsApplication {
	
	
	@Autowired
	private BookRepo bookRepository;

	@Autowired
	private UserRepo userRepository;

	@PostConstruct
	public void addData2DB() {
		
	}

	@GetMapping("/getUsers")
	public List<User> getUsers() {
		return userRepository.findAll();
	}
	@PostMapping("/staticAddUser")
	public void staticAddUser() {
		userRepository.save(new User("Subhojit"));
	}

	@GetMapping("/getBooks")
	public List<Book> getBooks() {
		return bookRepository.findAll();
	}
	@PostMapping("/staticAddBook")
	public void staticAddBook() {
		bookRepository.save(new Book("Ramayana"));
	}
	

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMultipleDsApplication.class, args);
	}

}
